# Welcome PSB6351 Fall 2020 Class
Here you can find, work on, and submit materials for the class!

Using git is important for version control and collaborations!